<?php
include("repeatedcode/_dbconnection.php");
?>
<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">

    <title>We DiscussTech</title>
</head>
<body>
    <?php include('repeatedcode/_header.php') ?>
    <?php include('repeatedcode/_loginmodal.php') ?>
    <?php include('repeatedcode/_signupmodal.php') ?>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <div class="carousel-item active">
                
            <div id="image-container">
    <img id="dynamic-image" alt="Unsplash Dynamic Image" style="width: 2400px; height: 600px; object-fit: cover;"/>
</div>
            <!-- <img class="d-block w-100" src="https://api.unsplash.com/photos/random?query=technology&client_id=ZF_qOt0PL2KoV_ytQCAjFcQDoUwfojrxXhhlbpTgRPk" alt="First slide"> -->
            </div>

            <div class="carousel-item">
                
    <img id="dynamic-image" alt="Unsplash Dynamic Image" style="width: 2400px; height: 600px; object-fit: cover;"/>
            <!-- <img class="d-block w-100" src="https://source.unsplash.com/2400x800/?mysql,javaScript" alt="Second slide"> -->
            </div>
            <div class="carousel-item">
    <img id="dynamic-image" alt="Unsplash Dynamic Image" style="width: 2400px; height: 600px; object-fit: cover;"/>
                
            <!-- <img class="d-block w-100" src="https://source.unsplash.com/2400x800/?python,code,html" alt="Third slide"> -->
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
    <div class="container my-3 text-center">
        <h2 class="text-center">DiscussTech - Categories</h2>
        <div class="row">
            <?php
            $sql = "SELECT * FROM categories";
            $result = $connection->query($sql);
            while ($categories_row = $result->fetch_assoc()) {
                $id = $categories_row['categories_id'];
                echo ' <div class="col-md-4 my-3">
                            <div class="card" style="width: 18rem;">
                            <img id="dynamic-image-' . $id . '" class="card-img-top" alt="Dynamic Image">    
                                <div class="card-body">
                                    <h5 class="card-title"><a href="question_list.php?catid=' . $id . ' ">' . substr($categories_row['categories_name'], 0, 90) . '</a></h5>
                                    <p class="card-text">' . substr($categories_row['categories_description'], 0, 90) . '...</p>
                                    <a href="question_list.php?catid=' . $id . ' " class="btn btn-primary">View threads</a>
                                </div>
                            </div>
                        </div>';
            }
            ?>
        </div>
    </div>

    <?php include('repeatedcode/_footer.php') ?>

    <!-- Optional JavaScript; choose one of the two! -->

    <script>
   
    const UNSPLASH_API_URL = 'https://api.unsplash.com/photos/random';
    const ACCESS_KEY = 'ZF_qOt0PL2KoV_ytQCAjFcQDoUwfojrxXhhlbpTgRPk'; 

    async function loadUnsplashImage() {
        try {
            const response = await fetch(`${UNSPLASH_API_URL}?query=technology`, {
                headers: {
                    Authorization: `Client-ID ${ACCESS_KEY}`
                }
            });

            if (!response.ok) {
                throw new Error('Failed to fetch image');
            }

            const data = await response.json();

            
            const imageUrl = data.urls.regular;

            
            const imgElement = document.getElementById('dynamic-image');
            imgElement.src = imageUrl;
            imgElement.alt = data.alt_description || 'Dynamic Unsplash Image';
        } catch (error) {
            console.error('Error loading Unsplash image:', error);
        }
    }

    // Call the function to load the image
    loadUnsplashImage();
</script>

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj" crossorigin="anonymous"></script>


    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-eMNCOe7tC1doHpGoWe/6oMVemdAVTMs2xqW4mwXrXsW0L84Iytr2wi5v2QjrP/xp" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.min.js" integrity="sha384-cn7l7gDp0eyniUwwAZgrzD06kc/tftFf19TOAs2zVinnD/C7E91j9yyk5//jjpt/" crossorigin="anonymous"></script>
</body>


<script>
       const UNSPLASH_API_URL2 = 'https://api.unsplash.com/photos/random';
    const ACCESS_KEY2 = 'ZF_qOt0PL2KoV_ytQCAjFcQDoUwfojrxXhhlbpTgRPk'; 

    
    async function loadUnsplashImage(imageId, category) {
        try {
            const response = await fetch(`${UNSPLASH_API_URL2}?query=${category}`, {
                headers: {
                    Authorization: `Client-ID ${ACCESS_KEY2}`,
                },
            });
            if (!response.ok) {
                throw new Error('Failed to fetch image');
            }
            const data = await response.json();
            const imageUrl = data.urls.regular;
            const imgElement = document.getElementById(imageId); 
            imgElement.src = imageUrl; 
            imgElement.alt = data.alt_description || 'Dynamic Image'; 
        } catch (error) {
            console.error('Error loading Unsplash image:', error);
        }
    }

    
    document.querySelectorAll('[id^="dynamic-image-"]').forEach((imgElement) => {
        const categoryId = imgElement.id.replace('dynamic-image-', ''); 
        const category = 'technology'; 
        loadUnsplashImage(imgElement.id, category);
    });
</script>


</html>