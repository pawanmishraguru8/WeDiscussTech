<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">

	<title>Aout Us!</title>
</head>

<body style="background-color:white;">
	<?php include('snavbar.php') ?>




	<p style="text-align:center; font-size: 25px;">We DiscussTech is a Professional Educational Platform. Here we will provide you only interesting content,</p>
	<p style="text-align:center; font-size: 25px;">which you will like very much. We're dedicated to providing you the best of Educational, with a focus on</p>
	<p style="text-align:center; font-size: 25px;"> dependability and Tech Toutorial. We're working to turn our passion for Educational into a booming online website. </p>
	<p style="text-align:center; font-size: 25px;">We hope you enjoy our Educational as much as we enjoy offering them to you.</p>
	<p style="text-align:center; font-size: 25px;">I will keep posting more important posts on my Website for all of you. Please give your support and love.</p>
	<p style="text-align:center; font-size: 25px;">Thanks For Visiting Our Site<br><br>
		<span style="color: blue; font-size: 30px; font-weight: bold; text-align: center;">Have a nice day!</span>
	</p>
</body>

</html>