<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
.footer {
   position:-webkit-sticky;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: black;
   color: white;
   text-align: center;
}
</style>
    <title>Document</title>
</head>
<body>
<?php
echo '
 <div class="footer" ;">


<p class = "text-center pt-1 pb-1 mb-0" > 
 Designed By Pawan Mishra  | Copyright &copy; <script>
                    document.write(new Date().getFullYear())
                </script> All Rights are reserved by &nbsp 
                <a href="index.php"><span style="font-size: 15px;"> DicussTech </span>
                    </a></p>
 </div>



            
';

?>
    
</body>
</html>