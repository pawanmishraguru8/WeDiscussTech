
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

<nav  class="navbar navbar-expand-lg navbar-dark bg-dark">
 
  <a class="navbar-brand" href="/prc/index.php">
      <img src="logo.png" alt="" width="30" height="24" class="d-inline-block align-text-top">
      We DiscussTech 
    </a>

 
   
   
 
 
</nav>