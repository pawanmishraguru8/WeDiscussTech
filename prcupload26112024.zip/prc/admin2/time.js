setTimeout(()=>{
    const box = document.getElementById('mes');
    box.style.display = 'none';

}
,2000
);